#include "client.h"

// The Judy Client
int main(int argc, char * argv[]){
    return run_client(argc, argv, JUDY);
}