#include "client.h"

// The Tina client
int main(int argc, char * argv[]){
    return run_client(argc, argv, TINA);
}